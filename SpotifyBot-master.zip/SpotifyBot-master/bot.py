import TOKEN
import telebot

bot = telebot.TeleBot(TOKEN.TOKEN)
